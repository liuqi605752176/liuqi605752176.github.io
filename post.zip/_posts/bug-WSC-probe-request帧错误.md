---
title: '[bug]WSC probe request帧错误'
comments: true
date: 2019-06-01 02:40:53
images: "images/abstract/bug_20190601.jpg"
categories: BUG记录
tags:
    - WSC
    - wifi认证
    - WPS
---
![bug_20190601](bug_20190601.jpg)
# BUG 详情
> 此bug是在项目在wifi认证阶段出现的，实验室测试出在WSC（WPS）的时候，发现probe request帧格式出现错误。
> 具体说来有两处错误

## config methods属性错误
> config methods：value长度为2字节，共16位。每一位代表Enrollee或register支持的WSC配置方法。
> usb, ethernet, label, display, virtual display, physical display, external NFC, internal NFC, NFC interface, push button, virtual push button, physical push button, keypad。
> 按照此项目需要将此属性的 display, virtual display, push button, virtual push button位打开，算出此属性应该为**0x2280**，而此时测试出的结果为**0x3184**。

## model name等属性值为空
> 通过抓包发现，model name、manufacturer、model number、serial number 和 device_name 这些属性值为空

# 解决方案
> wpa_supplicant 通过解析wpa_supplicant.conf文件，来获取wifi的相关信息，如果需要更改config methods以及model name等属性，则可以在wpa_supplicant.conf文件中添加相关的词缀。
> 故我在wpa_supplicant.conf中添加如下信息：
```conf
device_name=M690
manufacturer=LONGCHEER
model_name=M690
model_number=M690
serial_number=123456
config methods=push_button virtual_push_button dispaly virtual_display
```