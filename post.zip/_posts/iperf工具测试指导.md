---
title: iperf工具测试指导
comments: true
date: 2019-05-23 11:36:18
images: "images/abstract/iperf.jpg"
categories: 工具和软件
tags: 
	- iperf
	- network		
---

![iperf原理](iperf.jpg)

# 安装iperf

## 下载iperf

> 在官网根据系统下载响应的版本  <https://iperf.fr/iperf-download.php>

## 解压

> 将下载的压缩包解压到C:/根目录 ，也可以自己指定目录

## 测试是否安装成功

> 进入cmd，输入"cd \"，进入C盘根目录
>
> 命令行模式下输入“dir”，查看iperf文件夹是否存在，存在则输入“cd iperf”,进入iperf文件夹。

![iperf路径](iperf文件夹.png)

# iperf指令参数介绍

| 参数 |                             说明                             |
| :--: | :----------------------------------------------------------: |
|  -c  |       iperf -c ip_addr:客户端模式，ip_addr为服务器地址       |
|  -i  |   以秒为单位显示报告间隔，比如：iperf -c 222.35.11.23 -i 2   |
|  -u  |         使用UDP协议，发送UDP数据包，默认使用TCP连接          |
|  -w  | 指定TCP窗口大小，默认是8KB(**此参数比较重要，需要针对不同的带宽和时延进行调整**) |
|  -t  |    测试时间长，默认10秒，比如：iperf -c 222.35.11.23 -t 5    |
|  -n  | (一般配合UDP协议时使用)指定传输的字节数，比如：iperf -c 222.35.11.23 -n 100000 |
|  -P  | 指定同时进行的TCP/UDP连接数(**对于高带宽测速，需要该参数建立多条TCP/UDP连接以测得更准确的速率**) |
|  -p  |       指定端口号，比如：iperf -c 222.35.11.23 -p 5555        |
|  -b  |                  使用的带宽，用于udp测试中                   |
|  -s  |                     iperf -s :服务器模式                     |

# 实例

> 测试一个路由器lan口到wifi的一个吞吐量。

## 测试环境

> 两台PC,待测路由器。
>
> PC-A通过网线与待测路由相连得到ip地址：192.168.0.25，
>
> PC-B通过待测路由发出的wifi进行连接得到ip地址：192.168.0.35

## TCP测试

### lan -> wifi

> PC-B(跑服务端)：iperf -s -w2m -i 1
>
> PC-A(跑客户端)：iperf -c 192.168.0.35 -i 1 -t 1200

### wifi ->lan

> PC-A(跑服务器端)：iperf -s -w2m -i 1
>
> PC-B(跑客户端)：iperf -c 192.168.0.25 -i 1 -t 1200

## UDP测试

### lan -> wifi

> PC-B(跑服务端)：iperf -s -u -i 1
>
> PC-A(跑客户端)：iperf -c 192.168.0.35 -i 1 -t 1200 -b300M

### wifi ->lan

> PC-A(跑服务器端)：iperf -s -u -i 1
>
> PC-B(跑客户端)：iperf -c 192.168.0.25 -i 1 -t 1200 -b300M

> 这个测试的是udp wifi在300M速率下的吞吐量情况。我手上的这台mifi产品在300M速率下
>
> tcp：wifi的tx能到150 rx 150
>
> udp：wifi的tx能到156 rx 156

> **数据仅供参考**

