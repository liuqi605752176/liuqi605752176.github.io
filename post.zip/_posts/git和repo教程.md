---
title: git和repo教程
comments: true
date: 2019-08-17 14:15:24
images: "images/abstract/2019081702.jpg"
categories: linux应用
tags:
	- git
	- repo
---
![2019081702.jpg](2019081702.jpg)
# git常用命令

## git clone

git clone命令是代码克隆的命令，完整命令为：
git clone ssh://username@Gerrit-IP:29418/库名 –b 分支名
当我们在ssh配置文件 vi ~/.ssh/config 中添加了用户配置后，可以使用 git clone ssh://Gerrit-IP/库名 –b 分支名  下载

## git pull

更新代码仓库

## git branch

git branch 查看本地分支，可以使用git branch | grep XXX 进行有条件的查询
git branch –a 查看远程分支，类似的可以使用git branch -a| grep XXX 进行有条件的查询

## git checkout

git 切换分支 远程分支名命令
git checkout –b 本地分支名 远程分支名 【远程分支名型如remotes/origin/master】

## git add

git add是将修改提交到暂存区的命令常用的有：git add .和git add -u
git add . 是将所有变化提交到暂存区，包括修改内容及新文件
git add –u 是将修改过的文件提交到暂存区
通常情况下使用git add .即可

## git rm

git rm 文件名 git上删除文件的命令，和手动删除之后git add .一样，可以看做是省了一个git add .

## git status

查看有哪些文件做了修改，或者是否有新增/删除

## git diff

git diff 不加参数默认比较工作区与暂存区
git diff [<commit-id>] [<commit-id>] 比较两个commit-id之间的差异

## git commit

git commit -m “” 提交到本地库“”中填写描述
git commit -amend 在上一笔提交的基础上追加提交 
git commit -F commitmessge.txt     以此文件的格式提交描述

## git log

查看提交log，包括commitid 提交描述 changeid

## git merge

git merge 远程分支名 将远程分支合入到当前工作分支
一般会有大量冲突，需要工程师手动解冲突
一般SCM升级基线使用，不建议工程师手动使用

## git cherry-pick

git cherry-pick [<commit-id>] 挑单命令，从另一个分支挑到现有分支
如果有冲突需要手动解冲突
解冲突后需要git commit手动进行提交
或者在git add .后使用git cherry-pick –continue继续

## git revert

git revert [<commit-id>] 回退命令将某一笔提交会退掉
回退掉之后需要 git add . & git commit进行提交

## git reset & git clean

git reset --hard HEAD~1 是回退到某个版本的操作，这边有几个参数
 --soft 不删除改动代码，撤销commit，不撤销add **|** --mixed 不删除改动代码，撤销commit，撤销add **|** --hard 删除改动代码，撤销commit，撤销add
HEAD~1表示回退一次提交同理可以使用HEAD~2， HEAD~3等等HEAD代表的是当前的节点版本
git clean 一般和git reset –hard 一起用，reset影响被track过的文件，clean清理没有被track过的文件
git clean –dfx
通常情况下修改代码前忘记更新了可以用这个方法处理，处理完了使用git pull

## git push

常规命令： git push username@hostname:29418/projects branch1:refs/for/branch2
查看仓库下的.git/config
例如：
[remote "origin"]
​          url = ssh://172.16.16.121/qc-repository/zprojects
​          fetch = +refs/heads/*:refs/remotes/origin/*
username@hostname:29418/projects 这一块参照url可以用origin替换
branch1代表本地分支如果是当前指向的工作空间可以用HEAD代替
branch2代表远程分支当同一个提交需要往两个不同的分支上提交的时候直接切换这边的分支名即可达成
简化后的形式为：git push origin HEAD:refs/for/branch2
git push的两种方式
HEAD:refs/for/branch2
使用refs/for/branch2提交会生成一条gerrit网址的链接需要reviewer合入
HEAD:refs/heads/branch2
使用refs/heads/branch2提交会直接推送到gerrit服务器上，很危险，一般不开放，需要发邮件向SCM申请

# repo常用命令

1. Android 使用 Git 作为代码管理工具，使用 Gerrit 进行代码审核以便更好的对代码进行集中式管理，还开了 Repo 命令行工具，对 Git 部分命令封装，将百多个 Git 库有效的进行组织。

2. REPO根据manifest文件进行pull/push代码。

3. Manifest文件被称为清单文件个清单库可以包含多个清单文件和多个分支，每个清单文件和分支都有对应的版本，清单文件以xml格式组织的，放在.repo/manifests这个库里面

4. remote元素：定义远程版本库caf以及地址172.16.*.*

5. default元素：设置远程版本库caf以及默认分支master。

6. project元素：path属性表示在工作区克隆的位置，name属性表示该GIT库的远程版本库的相对路径。project元素的子元素copyfile，定义了项目克隆后的一个附件动作，从src拷贝文件到dest

## repo init

Repo init 的完整命令如下：
repo init -u ssh://username@Gerrit-IP:29418/manifest -b branchname -m manifest.xml
同一个清单仓库分支中切换其他的xml文件，使用如下命令：
repo init -m manifest.xml

## repo sync

repo sync 同步代码
repo sync project 可以选择只同步project库
repo sync  -j$Thread 多线程更新
repo sync --dx 把代码回退至manifest清单文件中指定的revision并clean
repo sync –f 强制更新
以上命令可以拼接，例如：repo sync -c –no-tags –j8

## repo start branch --all

给所有git库创建基于当前工作区分支的本地分支

## repo checkout branch

所有git库分支切换至branch

## repo branches

查看所有git库分支

## repo diff [project]

查看工作区差异

## repo stage -i

相当于给所有库git add -I

## repo prune

删除已经合并的分支

## repo abandon branch

删除指定分支

## repo status

查看文件状态

## repo forall -c 'command'

迭代器，在所有git 库中执行command命令
repo forall -c 'ID='git log --before="2019-08-08 12:00" --after="2019-08-08 13:00" -1 --pretty=format:"%H"'; git reset --hard $ID' 
这条指令是将所有的git库回退到某一天的代码

## repo upload

把代码推送至gerrit审核服务器
