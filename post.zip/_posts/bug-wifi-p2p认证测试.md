---
title: '[bug]wifi-p2p认证测试'
comments: true
date: 2019-06-16 01:49:02
images: "images/abstract/bug_20190616_01.jpg"
categories: BUG记录
tags:
	- wifi认证
	- p2p
---

![bug_20190616_01.jpg](bug_20190616_01.jpg)

# BUG详情

> 此bug在项目wifi认证阶段出现的
> Direct P2P-6.1.12:it failed at step 11,the more data bit shall be 1 not 0.

# 解决方案

## step1

```shell
adb root
adb pull /vendor/etc/wifi/WCNSS_qcom_cfg.ini .
# add/modify below item in your WCNSS_qcom_cfg.ini file.
# gApLinkMonitorPeriod = 45
# gGoLinkMonitorPeriod = 45
# gGoKeepAlivePeriod = 255
# gApKeepAlivePeriod = 255
adb push WCNSS_qcom_cfg.ini /vendor/etc/wifi/ adb reboot
```

## step 2

> make sure iwpriv tool in test phone.

```shell
adb root
adb shell
which iwpriv
```

> if output show a path such as '/system/bin/iwpriv' can indicate iwpriv tool in your test phone
