---
title: android P wifi模块分析之wifi系统框架
comments: true
date: 2019-07-06 03:49:19
images: "images/abstract/20190706_02.jpg"
categories: wifi模块
tags:
	- wifi
	- wpa_supplicant
---

![20170906_02.jpg](20190706_02.jpg)
# 前言

> 这一篇是wifi这一系列的第一篇，讲述android P wifi的一个代码流程分析。这也是我到新公司接触到android开始，对wifi的上层的一次深入学习，因为我之前只是在linux层面接触到wifi。仅以此系列文章记录我对android wifi世界的理解。

# Android wifi 框架图

![android wifi 框架图](android wifi 框架图.jpg)

# Android wifi 源码结构

## Wifi Setting层

> packages/apps/Setting/src/com/android/settings/wifi/
>
> 主要的类：

|        类        |          功能          |
| :--------------: | :--------------------: |
| WifiSetting.java | 负责显示Wifi的设置界面 |
| WifiEnabler.java |   负责Wifi的开关逻辑   |
| WifiDialog.java  |    负责Wifi的对话框    |
|  WifiInfo.java   | 表示Wifi的相关配置信息 |

## Wifi framework层

> frameworks/base/wifi/Java/android/net/wifi/
>
> frameworks/base/core/java/android/net/
>
> frameworks/opt/net/wifi/service/java/com/android/server/wifi
>
> 主要的类：

|        类        |                             功能                             |
| :--------------: | :----------------------------------------------------------: |
|   WifiManager    | 它是Wifi模块向外部应用透漏出来的接口，其它所有应用都可以通过WifiManager来操作Wifi的各项功能，但是WifiManager本身不具备处理请求的能力，而是把所有的请求转发给WifServiceImpl来处理 |
|   WifiService    | Framework中Wifi功能的总入口，负责Wifi功能的核心业务。它是服务器端的实现，作为Wifi部分的核心，处理实际的驱动加载、扫描、链接、断开等命令，以及底层上报的事件。对于主动的命令控制，WiFi是一个简单的封装，针对来自客户端的控制命令，调用相应的WifiNative底层实现 |
| WifiServiceImpl  | 本身也不具备处理请求的能力，而是将请求分类后交给不同的处理者处理，比如WifiStateMachine。 |
| WifiStateMachine | 它是一个复杂的状态机，维护了Wifi的启动、扫描、连接、断开等多个状态。它运行自己独有的线程中，拥有自己的消息队列。 |
| WifiStateTracker | 除了负责WiFi的电源管理模式等功能外，其核心是WifiMonitor所实现的事件轮询机制，以及消息处理函数handleMessage() |
|   WifiMonitor    | 专门负责接收来自Wpa_supplicant的事件，并将这些信息进行分类再交予StateMachine处理。 |
|    WifiNative    | 主要是提供一些native方法用于wifi framework层和WPAS通信。WifiNative的主要实现都在wifi.c函数里,WifiNative不过是将其封装,供framework层调用 |

> **注：WifiService 和 WifiMonitor 是整个模块的核心。WifiService 负责启动关闭 wpa_supplicant、启动关闭 WifiMonitor 监视线程和把命令下发给 wpa_supplicant,而 WifiMonitor 则负责从 wpa_supplicant 接收事件通知。也就是说WifiService负责wifi整个流程的控制，而WifiMonitor负责监视底层的事件**

## wifi jni层

> frameworks/base/core/jni/android_net_wifi_Wifi.cpp
>
> android_net_wifi_Wifi.cpp就是典型jni接口，通过它可以直接调用Wifi的硬件抽象层

## wifi Hardware层

> hardware/libhardware_legacy/wifi/wifi.c
>
> Wifi Hardware层也叫wpa_supplicant适配层，是通用wpa_supplicant的封装。wpa_supplicant适配层起着承上启下的作用，主要用于与wpa_supplicant守护进程的通信，以供给Wifi框架层使用

## wpa_supplicant层

> external/wpa_supplicant_8/
>
> 该层是Wifi FrameWork层的基石，也叫Wifi服务层。经过编译后主要结果是生成动态库libwpa_client.so和可执行程序wpa_supplicant。

1. wpa_client (生成库libwpaclient.so)

   external/wpa_supplicant_8/wpa_supplicant/src/common/wpa_ctrl.c
2. wpa_server (生成守护进程wpa_supplicant)
external/wpa_supplicant_8/wpa_supplicant/main.c

## wifi kernel层

> kernel/drivers/net/wireless
