---
title: "[bug]打开wlan开关不显示扫描的SSID结果"
comments: true
date: 2019-08-17 13:45:06
images: "images/abstract/2019081701.jpg"
categories: BUG记录
tags:
	- wifi
---
![2019081701.jpg](2019081701.jpg)
# BUG详情

> 关闭wlan开关再打开，WIFI列表不显示扫描结果，没有可选择的无线网络。

# LOG分析

> 根据所提供的bugreport的日志分析如下：

```bash
08-16 09:43:27.519 1000 1396 4707 D WifiService: setWifiEnabled: true pid=2029, uid=1000, package=com.android.systemui
08-16 09:43:27.520 1000 1396 4707 I chatty : uid=1000(system) Binder:1396_11 expire 1 line
08-16 09:43:27.522 1000 1396 1396 V SettingsProvider: Notifying for 0: content://settings/global/wifi_on
08-16 09:43:27.523 wifi 834 834 W wificond: No pno scan started
08-16 09:43:27.523 wifi 834 834 W wificond: Scheduled scan is not running!

08-16 09:43:27.570 gps 942 966 I LOWI-8.6.0.44: [LOWIController] isWifiEnabled: Wifi is now disabled
08-16 09:43:27.571 gps 942 32270 I LOWI-8.6.0.44: [LOWIScanResultReceiver] Thread terminate was requested
08-16 09:43:27.572 gps 942 32271 I LOWI-8.6.0.44: [LOWIScanResultReceiver] Thread terminate was requested

08-16 09:43:27.701 wifi 620 620 E android.hardware.wifi@1.0-service: Failed to open directory: Permission denied
08-16 09:43:27.701 wifi 620 620 E android.hardware.wifi@1.0-service: Error occurred while deleting old tombstone files
08-16 09:43:27.701 wifi 620 620 E android.hardware.wifi@1.0-service: Error writing files to flash

08-16 09:43:27.702 wifi 620 32272 I android.hardware.wifi@1.0-service: Legacy HAL stop complete callback received
08-16 09:43:27.774 1046 835 32180 I OMX-VENC: venc_dev: stats: avg. fps 24.08, bitrate 159559
08-16 09:43:27.906 wifi 620 620 I android.hardware.wifi@1.0-service: Wifi HAL stopped
08-16 09:43:27.917 wifi 620 620 I android.hardware.wifi@1.0-service: Wifi HAL started
08-16 09:43:27.937 1000 1396 1921 I chatty : uid=1000(system) WifiP2pService expire 12 lines
08-16 09:43:28.018 wifi 32283 32283 I chatty : uid=1010(wifi) expire 305 lines
08-16 09:43:28.067 gps 942 966 I LOWI-8.6.0.44: [LOWIController] isWifiEnabled: Wifi is now enabled

08-16 09:43:28.077 gps 942 966 I CLD80211: lowi-server: initialized exit socket pair
08-16 09:43:28.078 gps 942 966 I CLD80211: lowi-server: nlctrl family id: 16 group: oem_msgs mcast_id: 25
08-16 09:43:28.088 wifi 620 620 I android.hardware.wifi@1.0-service: Adding interface handle for wlan0
08-16 09:43:28.088 wifi 620 620 I android.hardware.wifi@1.0-service: Adding interface handle for p2p0
08-16 09:43:28.088 wifi 620 620 I android.hardware.wifi@1.0-service: Adding interface handle for wlan1
08-16 09:43:28.089 wifi 620 620 I android.hardware.wifi@1.0-service: Configured chip in mode 0
08-16 09:43:28.108 wifi 834 834 I wificond: create scanner for interface with index: 29
08-16 09:43:28.108 wifi 834 834 I wificond: subscribe scan result for interface with index: 29

08-16 09:43:28.171 1000 1396 1921 E WifiP2pService: Unhandled message { when=-1ms what=131203 target=com.android.internal.util.StateMachine$SmHandler }
08-16 09:43:30.164 1000 1396 1920 I chatty : uid=1000(system) WifiScanningSer expire 10 lines
08-16 09:43:30.166 gps 942 32285 I LOWI-8.6.0.44: [LOWI-Scan] lowi_close_record:Scan done in 329380726ms, 13 APs in scan results
08-16 09:43:28.178 1000 1396 1921 E WifiP2pService: Unhandled message { when=-1ms what=131203 target=com.android.internal.util.StateMachine$SmHandler }
```

```shell
2019-08-16T09:43:28.172 - Set WiFi enabled
2019-08-16T09:43:28.172 - Starting up WifiConnectivityManager
2019-08-16T09:43:28.177 - startConnectivityScan: screenOn=true wifiState=transitioning scanImmediately=true wifiEnabled=true wifiConnectivityManagerEnabled=true
2019-08-16T09:43:28.177 - handleConnectionStateChanged: state=disconnected
2019-08-16T09:43:28.178 - scheduleWatchdogTimer
2019-08-16T09:43:28.178 - startConnectivityScan: screenOn=true wifiState=disconnected scanImmediately=true wifiEnabled=true wifiConnectivityManagerEnabled=true
2019-08-16T09:43:30.171 - AllSingleScanListener onResults: start network selection
2019-08-16T09:43:30.172 - Disabled saved networks:
2019-08-16T09:43:30.172 - "Xiaomi_7ED0_812F":3 reason=NETWORK_SELECTION_DISABLED_BY_WIFI_MANAGER, count=1; 
"Xiaomi_7ED0":4

2019-08-16T09:43:30.173 - Networks filtered out due to low signal strength: MI-V6:48:4a:e9:f7:63:63(2.4GHz)-88 / MIOT:04:bd:88:59:fe:90(5GHz)-90 / MIPublic:04:bd:88:59:fe:91(5GHz)-89 / MI-V6:04:bd:88:59:fe:93(5GHz)-90 / MI-IPv6:04:bd:88:59:fe:94(5GHz)-89 / HUAWEI6677:3c:fa:43:31:fe:70(2.4GHz)-93 / HIWIFI RENREN:d4:ee:07:0c:70:66(2.4GHz)-92 / Xiaomi固件:8c:be:be:40:0d:1c(2.4GHz)-89 / MIOT:94:b4:0f:06:6a:10(5GHz)-90 / MIPublic:94:b4:0f:06:6a:11(5GHz)-89 / MI-IPv6:94:b4:0f:06:6a:14(5GHz)-88 / 
2019-08-16T09:43:30.173 - About to run SavedNetworkEvaluator :
2019-08-16T09:43:30.174 - 
[ HWCS 5c:c3:07:63:aa:44 RSSI:-73 ] RSSI score: 48, Secure network bonus: 80, ## Total score: 128

2019-08-16T09:43:30.174 - SavedNetworkEvaluator selects "HWCS":0 : 5c:c3:07:63:aa:44
2019-08-16T09:43:30.175 - AllSingleScanListener: WNS candidate-"HWCS"
2019-08-16T09:43:30.175 - connectToNetwork: Connect to "HWCS":any from Disconnected
2019-08-16T09:43:35.359 - handleConnectionStateChanged: state=transitioning
2019-08-16T09:43:35.359 - startConnectivityScan: screenOn=true wifiState=transitioning scanImmediately=false wifiEnabled=true wifiConnectivityManagerEnabled=true
```

# 结论

> 打开wifi后，立即触发连接了之前保存过的网络，而且信号-75,信号很弱，一直连接不上。所以连接过程较长，而**在连接过程中是禁止扫描的**，所以一直刷新不出来扫描结果

# 后续验证方案

> 可以使用下面两种方法验证是否是上述原因：

1. 保存一个信号好的网络进行断开以及打开的操作
2. 删除已保存的网络进行尝试
