---
title: '[bug]cts-wifilinkstatus报错'
comments: true
date: 2019-06-16 03:00:51
images: "images/abstract/bug_20190616_02.jpg"
categories: BUG记录
tags: 
	- cts
	- wifi
---

![bug_20190616_02.jpg](bug_20190616_02.jpg)

#  BUG详情

> 此bug是在cts测试时遇到的
>
> 看logcat报错显示是wifigetlinklayerstatus报错。
>
> 这个问题遇到很多，cts好几条都是与之相关，还有在设置界面查看电池电量时，切换页面时很慢查看log，也是这个报错

## ctsincidenthostTestCases not pass
> log:
```bash
.com.android.server.cts.BatteryStatsValicationTest#testRealtime ERROR:
	junit.framework.AssertionFailedError.

```
## vtshalwifiv1_0Host not pass
> log:
```bash
vtshalwifiv1_0Host#wifistaifacehidltest.linklayerstatscollection(default)_32bit
hardware/interfaces/wifi/1.0/vts/functional/wifi_sta_iface_hidl_test.cpp:152:Failure
```
## get wifi status timeout in setting 
> log:
```bash
WifiHAL:wifi_get_link_stats:requestResponse Error:-7
wifivendorhal:getwifilinklayerstats failed {.code =
	ERROR_UNKONWN,.description=.timed out}
```
## ctsstatsHostTestCases not pass
> log:
```bash
android.cts.stats.atom.HostAtomTests#testWifiActivityInfo
ERROR:java.lang.indexoutofboundsexception:index:0
```
# 解决方案

> patch:
```c
//core/wma/src/wma_utils.c

tx_power_level_values=(uint8_t *)param_tlvs->tx_time_per_power_level;
-if(fixed_param->total_num_tx_power_levels >)
+if(fixed_param->total_num_tx_power_levels && 
+ fixed_param->total_num_tx_power_levels >
rs_results->total_num_tx_power_levels){
//...
}
```
# Root Cause
> Check if rs_results->total_num_tx_power_levels is allocated, before checking the OOB 
> in wma_unified_radio_tx_power_level_stats_event_handler for new 
> fixed_param->total_num_tx_power_levels 
> Original code was not present "if (rs_results->total_num_tx_power_levels", 
> new code make sure 'rs_results->total_num_tx_power_levels' is allocated firstly. 

> this analysis provided from Qcom R&D team. 
