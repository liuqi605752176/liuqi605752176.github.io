---
title: "[bug]wlan_logs-disapper"
comments: true
date: 2019-06-25 02:50:58
images: "images/abstract/20190706_01.jpg"
categories: 
tags:
	- selinux
	- wifi
---
# BUG
> After the machine is flashed,the wlan_logs folder appears in the file, and the
> log is continuously printd.
>
> when i use the latest version to test ,the bug changed!
>
> when i open the T card log,the wlan_logs disapper,so i record the analysis in
> my blog.

# Expected result
> wlan_logs closed by default,when i open T card log ,the wlan_logs appears.

# T card log
> input telephone number "*#*#87#*#*"
> click the button that "manual test"
> click the button "t card log"
> choose "Method 2"

# Analysis
> when i serch the code, cnss_diag_system has been compiled.so i suspect the
> service did not start.
> "/device/qcom/sdm660_64/init.target.rc".i suspect the service add in
> init_target.rc do not start.so i changed to start service in init.rc.

# Resolved
## add in init.rc
> "/system/core/rootdir/init.rc"
```.rc
//add wlan log
service cnss_diag /system/bin/cnss_diag_system -q -f
	class main
	user system
	group system wifi inet net_admin sdcard_rw media_rw diag
	disabled
	oneshot

on property:sys.cnss_diag.enable=1
	start cnss_diag
//end
```
> when i change this case, i didnot get the Expected results.but when i input
> in the bush "setprop sys.cnss_diag.enable 1",the wlan_logs appears.
> when i catch the logcat log,i found the problem

```log
logcat -vv | grep scontext
cnss_diag_styste: type=1400 audit(0.0:52822): avc: denied{ create } for
scontext=u:r:cnss_diag_system:s0 tcontext=u:r:cnss_diag_system:s0
tclass=udp_socket permissive=0

```
> so i need to add cnss_diag_system selinux

## fix selinux 

> add cnss_diag_system selinux
> "device/qcom/sepolicy/vendor/common/file_contexts"

```
/(vendor|system)/bin/cnss_diag_system   u:object_r:wcnss_service_exec:s0

```
> "device/qcom/sepolicy/vendor/common/wcnss_service.te"
```
# for wlan driver/fw logs
allow wcnss_service diag_device:chr_file { read write };

```
# Root cause
> the service donot start and selinux 


