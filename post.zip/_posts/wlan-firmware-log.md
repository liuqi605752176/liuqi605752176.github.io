---
title: wlan firmware log
date: 2019-05-14 11:28:00
images: "images/abstract/wlan_firmware_log.jpg"
comments: true
categories: linux调试技巧
tags: 
	- wifi
	- firmware log
---

# 修改WCNSS_qcom_cfg.ini

> 将下面两条词缀全置为1

```
#Enable firmware log
gEnablefwlog=1
# Enable broadcast logging to the userspace entities
gMulticastHostFwMsgs=1
```

# 确认Data.msc

```bash
//检测
ls -al /firmware/image/
//若没有Data.msc执行以下命令
adb push Data.msc /firmware/image/
```

# 更改Data.msc权限

```bash
chmod 777 Data.msc
```

# 更改linux内核日志级别

## 查询

```bash
cat /proc/sys/kernel/printk
```

![printk1.png](printk1.png)

## 更改

```bash
echo 4 > /proc/sys/kernel/printk
```

## 确认

```bash
cat /proc/sys/kernel/printk
```

![printk2.png](printk2.png)

# 打开fw log

```bash
iwpriv wlan0 dl_report 1
iwpriv wlan0 dl_type 1
iwpriv wlan0 dl_loglevel 0
```

# 抓取log

```bash
cnss_diag -c > /data/fw_log.txt
```

![FWMSG.png](FWMSG.png)

> 如果生成的fw_log.txt文件出现如上图所示，说明firmware log已经正常抓取！！

