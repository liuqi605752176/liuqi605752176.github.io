---
title: '[bug]how-to-close-wifi-powersave-and-autoscan'
comments: true
date: 2019-06-17 03:53:14
images: "images/abstract/20190617_01.jpg"
categories: BUG记录
tags:
	- wifi
	- power save mode
	- auto scan
---
![20190617_01.jpg](20190617_01.jpg)
# bug description
> wifi test need to close wifi power save mode and autoscan.

# close power save mode
> ensure the follow methods in WCNSS_qcom_cfg.ini

```shell
gEnableImps=0
gEnableBmps=0
FastTransitionEnable=0
FastRomeEnable=0
gEnableDFSchnlScan=0
gEnableRTSProfiles=0(for remove/wcn39x0)
gDualMacFeatureDisable=1(for wcn39x0)

```
# close auto scan
> connected to CMW500/M8860C,run ADB command to disable auto scan

```shell
iwpriv wlan0 dump 311 1 (remove wcn3680)
adb shell iwpriv wlan0 scan_disable 1(for wcn39x0)
adb shell iwpriv wlan0 setUnitTestCmd 9 2 1 0 (for wcn39x0)
```
