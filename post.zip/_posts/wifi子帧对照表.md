---
title: wifi子帧对照表
comments: true
date: 2019-08-24 21:48:43
images: "images/abstract/2019082401.jpg"
categories: wifi模块
tags:
	- wifi
	- wireshark
---

![2019082401.png](2019082401.jpg)

| 帧类型/子类型              | 过滤器语法                            |
| :------------------------- | :------------------------------------ |
| Management frame           | wlan.fc.type == 0                     |
| Control frame              | Control frame wlan.fc.type == 1       |
| Data frame                 | wlan.fc.type == 2                     |
| Association request        | wlan.fc.type_subtype == 0x00          |
| Association response       | wlan.fc.type_subtype == 0x01          |
| Reassociation request      | wlan.fc.type_subtype == 0x02          |
| Reassociation response     | wlan.fc.type_subtype == 0x03          |
| Probe request              | wlan.fc.type_subtype == 0x04          |
| Probe response             | wlan.fc.type_subtype == 0x05          |
| Beacon                     | wlan.fc.type_subtype == 0x08          |
| Disassociate               | wlan.fc.type_subtype == 0x0A          |
| Authentication             | wlan.fc.type_subtype == 0x0B          |
| Deauthentication           | wlan.fc.type_subtype == 0x0C          |
| Action frame               | wlan.fc.type_subtype == 0x0D          |
| Block ACK requests         | wlan.fc.type_subtype == 0x18          |
| Block ACK                  | wlan.fc.type_subtype == 0x19          |
| Power save poll            | wlan.fc.type_subtype == 0x1A          |
| Request to send            | wlan.fc.type_subtype == 0x1B          |
| Clear to send              | wlan.fc.type_subtype == 0x1C          |
| ACK                        | wlan.fc.type_subtype == 0x1D          |
| Contention free period end | wlan.fc.type_subtype == 0x1E          |
| NULL data                  | wlan.fc.type_subtype == 0x24          |
| QoS data                   | QoS data wlan.fc.type_subtype == 0x28 |
| Null QoS data              | wlan.fc.type_subtype == 0x2C          |

