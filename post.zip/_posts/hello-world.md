---
title: The New World
date: 2019-05-08 12:14:56 
images: "images/abstract/helloworld.jpg"
categories: 生活点滴
comments: true
---
Welcome to my blog! This is my first personal blog.

## The New World

### 职业生涯
> 我从事linux驱动开发已经一年时间，之前也搭建过一个博客写了一些工作以及学习上的事，但是后来也不了了之，没能坚持的下去
现在我已经提了离职，准备去一个新公司开始新的生涯，所以准备这次重新开始，记录我的职业生涯

### 人生
> 我2019/5/2有了我一件人生大事，我买房了，在南通。尽管贷款了151W,还贷30年,每月要还8200+，但是还是很开心。
感觉我的人生踏入了一个新的阶段。以后的以后，请一定要加油！！！
